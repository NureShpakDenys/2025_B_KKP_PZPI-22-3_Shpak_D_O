export interface RegistrationRequest {
    username: string,
    email: string,
    password: string
}