export { SearchModal } from './search-modal.component'

