export const PLAYER_JS_PATH = "playerJS/playerjs.html"
export const BASE_URL = "http://localhost:5173"