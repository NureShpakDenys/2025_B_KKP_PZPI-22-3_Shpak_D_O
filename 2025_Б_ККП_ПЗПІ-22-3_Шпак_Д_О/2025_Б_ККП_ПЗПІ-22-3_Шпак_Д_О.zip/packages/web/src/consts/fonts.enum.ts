export enum FONTS {
    MONTSERRAT = 'Montserrat',
    JERSEY25 = 'Jersey25-Regular'
}