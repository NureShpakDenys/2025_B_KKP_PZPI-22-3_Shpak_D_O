export interface IChatPreviewType {
    id: string;
    targetUserId: string
    userAvatar: string;
    username: string;
    lastMessage: string;
}