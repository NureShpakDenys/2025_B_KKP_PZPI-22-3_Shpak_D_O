export interface IMessageType {
    id: string;
    createdAt: string;
    content: string;
    chatId: string;
    senderId: string;
}