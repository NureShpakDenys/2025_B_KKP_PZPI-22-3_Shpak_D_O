export interface IChatType {
    id: string;
    createdAt: string;
    userId1: string;
    userId2: string;
}