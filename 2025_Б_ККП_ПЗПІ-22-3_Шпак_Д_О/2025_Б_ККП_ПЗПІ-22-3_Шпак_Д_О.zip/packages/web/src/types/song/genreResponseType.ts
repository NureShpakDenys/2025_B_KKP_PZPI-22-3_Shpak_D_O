export interface GenreResponseType{
    genreName: string;
    genreCover: string;
}