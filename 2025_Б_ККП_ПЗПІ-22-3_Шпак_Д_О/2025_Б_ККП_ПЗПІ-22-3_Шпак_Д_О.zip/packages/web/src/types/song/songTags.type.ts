export interface ISongTags {
    name: string;
}
