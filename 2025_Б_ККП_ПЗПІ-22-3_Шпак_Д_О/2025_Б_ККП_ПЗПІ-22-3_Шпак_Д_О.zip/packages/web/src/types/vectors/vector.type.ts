export interface IVectorType {
    id?: string;
    criterion?: string;
    criterionId: string;
    mark: string;
}