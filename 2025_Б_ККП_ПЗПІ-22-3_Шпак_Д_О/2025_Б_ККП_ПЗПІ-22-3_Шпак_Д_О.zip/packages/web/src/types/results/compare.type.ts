export interface ICompareType {
    result: number;
    song2Id: string;
}