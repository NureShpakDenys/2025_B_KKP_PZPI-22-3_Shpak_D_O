export interface FollowType {
    id: string;
    username: string;
    role: string;
    profilePictureUrl: string;
    profileInfo: string;
}