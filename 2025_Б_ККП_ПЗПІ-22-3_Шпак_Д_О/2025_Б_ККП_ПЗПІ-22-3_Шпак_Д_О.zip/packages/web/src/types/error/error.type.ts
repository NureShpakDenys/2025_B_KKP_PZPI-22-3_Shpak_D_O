export interface ErrorType {
    status: number;
    message: string;
}