export interface ICriterionType {
    id: string;
    createdAt: string;
    updatedAt: string;
    name: string;
}