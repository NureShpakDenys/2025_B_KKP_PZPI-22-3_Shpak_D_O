package dtos

type TagDTO struct {
	Name string `json:"name"`
}
